class CmdActionEnum:
    def __init__(self):
        pass

    MOVE = 0
    HOLD = 1
    ATTACK = 2
    CAST = 3
    UPDATE = 4
    BUY = 5
    SELL = 6
    AUTO = 7
    RETREAT = 8
    RESTART = 100
