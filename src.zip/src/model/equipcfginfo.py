class EquipCfgInfo:
    def __init__(self, cfg_id, buy_price, sale_price, name, desc):
        self.cfg_id = cfg_id
        self.buy_price = buy_price
        self.sale_price = sale_price
        self.name = name
        self.desc = desc
