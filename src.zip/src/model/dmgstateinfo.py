# -*- coding: utf8 -*-

# 造成的伤害信息，注意这里记录的技能是技能槽位置，0表示普通攻击
# 注：一次返回中有可能有多段攻击伤害，都是由同一个技能触发的
class DmgStateInfo(object):
    def __init__(self, atker, tgt, skillslot, dmg):
        self.atker = atker
        self.tgt = tgt
        self.skillslot = skillslot
        self.dmg = dmg

    @staticmethod
    def decode(obj):
        atker = str(obj['atker'])
        tgt = str(obj['tgt']) if 'tgt' in obj else None
        skillslot = obj['skillslot'] if 'skillslot' in obj else None
        dmg = obj['dmg']
        return DmgStateInfo(atker, tgt, skillslot, dmg)

    def encode(self):
        json_map = {'atker': self.atker, 'tgt': self.tgt, 'skillslot': self.skillslot, 'dmg': self.dmg}
        return dict((k, v) for k, v in json_map.items() if v is not None)
