class BuffEnum:
    def __init__(self):
        pass

    STUN = 0
    SLOW = 1